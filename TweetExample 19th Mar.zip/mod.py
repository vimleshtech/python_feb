
def countword():
    num_words = 0
     
    a=open(r'C:\Users\Tech Vision\Desktop\tweet.txt', 'r')
    for line in a:
        words = line.split()
        num_words += len(words)
    print("Number of words:")
    print(num_words)
