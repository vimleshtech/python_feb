import tweepy




# Consumer keys and access tokens, used for OAuth
consumer_key = 'onOZzCY8ZYrL6vH5Ar62Nfx7y'
consumer_secret = 'PS49BxCnYa3TZ4X80BLeropopJLAm4rX2MZvoaBUonNzUx0Nn6'
access_token = '2874990028-8oO2RWEtNy3RLg5SS6GznSBNnlacf4srSKTocSN'
access_token_secret = 'W2wAKugyLpK1Fsrhe43j32hCEMRcNqzALS1hZnHYGFw0z'
 
# OAuth process, using the keys and tokens
auth =tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
 
# Creation of the actual interface, using authentication
api = tweepy.API(auth)


print('auth pass')

out = api.search(q='Narendra Modi',count=10)

a=open(r'C:\Users\Tech Vision\Desktop\tweet.txt','a')

for o in out:
    a.write(o.text.encode('utf8'))
    
a.close()


a=open(r'C:\Users\Tech Vision\Desktop\tweet.txt','r')

print(a.read())
a.close()

import mod 
mod.countword()


 
