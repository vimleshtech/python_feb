'''
abc
 = aca
 = bac
 = bca
 
'''
p=raw_input("enter")
d = list(p)
print(d)
f=len(d)
print(f)
for x in range (0,f):
    print'\n'
    for i in range(0,x+1):
        print d[i],

print


for i in range(1,len(p)+1):
    print(p[0:i])

    
for i in range(1,len(p)+1): 
    print(p[0:len(p)+1-i])  #p[0:10+1-i] 0:9 = all content  0:8 
    
'''p=raw_input("enter")
d = list(p)
print(d)
f=len(d)
print(f)
for x in range (f,0):
    print'\n'
    for i in range(x-1,0):
        print d[i],'''
