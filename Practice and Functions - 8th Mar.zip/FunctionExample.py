'''
Function
-function with default argument
-function with dynamic argument
-function with return multiple values
-recursive function
-anonyms function : lambda 

Note: python doesn't support function overloading

'''

#-function with default argument
def add(a,b,c=0,d=0):#c,d are optioan variable 
    e = a+b+c+d
    print(e)

'''
def add(a,b,c):  #overriding
    
    d = a+b+c
    print(d)
'''
#-function with dynamic argument
def mul(*args):
    print(args)
    o =1
    for d in args:
        o *= d

    print(o)
    
#-function with return multiple values
def getdata():
    a = int(input('enter data :'))
    b = int(input('enter data :'))
    return a,b


#recusive function
def fact(n):
    if n ==1:
        return n
    else:
        return n*fact(n-1)  # 5*4*3*2*1
    

x = lambda a: a*4

print(x(5))



#add(11,22)
add(11,2)
add(11,2,33)
add(11,22,33,33)

mul(11,222,333,44)
mul(33,33,4,2,2,2,2,2)


x,y = getdata()
add(x,y)

o = fact(5)
print(o)




