a=int(input('enter number'))
for x in range(1,a):
    print "(",    
    for f in range (1,x+1):
        if f<x:
            print f,'+',
        else:
            print f,
        
    print ")",
    if x < a-1:
        print '+',
        
    

'''a=int(input('enter number'))
for x in range(1,a,2):
    print "(",
    for f in range (0,x,2):
        
        print f,"+",
    print ")",
    print'+','''


    
'''a=int(input('enter number'))
for x in range(0,a,2):
    print "(",
    for f in range (0,x,2):
        f=f+1
        print f,'^',"+",
    print ")",
    print'+','''

