import pandas

d = pandas.read_csv('corr_out.csv')
print(d)

x = pandas.read_excel(r'C:\Users\vkumar15\Desktop\Sample - Superstore.xlsx',sheet_name='Orders')
print(x)


'''
Segment
City
State
Region
Category
Sub-Category
Product Name

group by sum of sales, profit  and write to output file

'''




