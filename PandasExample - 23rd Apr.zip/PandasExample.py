import pandas

ds = pandas.DataFrame() #create blank or empty dataframe
print(ds)

#convert list to dataframe / table
ids = [1,2,3,4,5,6]
name = ['raman','jatin','divya','ayush','mohit','ridhi']
gender = ['male','male','female','male','male','female']
salary = [20000,30000,24000,40000,56000,98000]

#create new dataframe from list
data = pandas.DataFrame(data={'eid':ids,'name':name,'gender':gender,'sal':salary})

print(data)

##show top 3 rows
print(data.head(3))

#show from buttom
print(data.tail(2))

#show row and col count / show shape
print(data.shape)

#show selected column
print(data['name'])

#show multiple column
print(data[['name','gender']])

#create new frame from existing dataframe
d =data[['name','gender']]
print(d)

      
#convert dataframe to array
dt = data.values
print(dt[2:5,]) # row index,col index , show row index from 2 to 4 

#filter row and cols
print(dt[:,1:4]) #all rows with 2nd to 4th cols (index 1 to 3)


##group , get male and female count
print(data.groupby('gender').size())
print(data.groupby('gender').sum()['sal']) #gender wise sum of sal
print(data.groupby('gender').max()['sal']) #gender wise max sal
print(data.groupby('gender').min()['sal']) #gender wise min sal 

##sorting / order by
print(data.sort_values('sal',ascending=True))
print(data.sort_values('sal',ascending=False))

#describe / show stats
print(data.describe())

## show details about dataframe
print(data.info())


#corr : relation between two or more than two variables
#how every variable is corellated with each other
d = data.corr()
print(d)

#write to file
d.to_csv('corr_out.csv')















