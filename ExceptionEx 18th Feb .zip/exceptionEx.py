
try:
     
     n = int(input('enter data :'))
     d = int(input('enter data :'))

     if d<0:
          e = ValueError('divisor cannot be less than 0')#create error message
          raise e #go to / send to except block 
     
     o = n/d
     print(o)
except ValueError as er: #type conversion error
     print(er)
except ZeroDivisionError as e:
     print(e)     
except:
     print('there is technical error, pls try after some time')
finally:
     print('end of block')


#addition of two numebrs
n = int(input('enter data :'))
d = int(input('enter data :'))

o =n+d
print(o)



