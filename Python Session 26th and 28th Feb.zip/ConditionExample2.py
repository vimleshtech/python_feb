#if elif elif elif  else...
hs = int(input('enter mark :'))
es = int(input('enter mark :'))
cs = int(input('enter mark :'))
ms = int(input('enter mark :'))

total = hs+es+ms+cs
avg = total /4

print(total)
print(avg)

if avg>=70:
    print('A')
elif avg>=60:
    print('B')
elif avg>=40:
    print('C')
else:
    print('F')
    
