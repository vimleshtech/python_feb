#while loop
i =1
while i<10:
    print(i) #print and new line 
    i = i+1
    
#print in same line
i =1
while i<10:
    print(i,end=',') #print and don't change line 
    i = i+1

#print in reverse order
i =10
while i>0:
    print(i)
    i = i-1

#for loop
for i in range(1,10):
    print(i)

#print in reverse order
for i in range(10,0,-1):
    print(i)


#wap to show sum of all even and odd numebrs between 1 to 100
se =0
so  =0
for i in range(1,101):
    if i % 2 ==0 :
        se =se+i
    else:
        so = so+i
print('sum of all even numebrs :',se)
print('sum of all odd numbers :',so)








    



    


    
