#take input from user 
sale = int(input('enter sale amout :'))


tax = 0 #default value

if sale >1000: #condition 
    tax = sale *.18   # 18 %


total = sale + tax
print('total amount :',total)

##if else

tax = 0 #default value

if sale >1000: #condition 
    tax = sale *.18   # 18 %

else:
    tax = sale *.05   #5 %    = sale * 05 /100
    
total = sale + tax
print('total amount :',total)

