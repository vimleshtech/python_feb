for i in range(1,10):
    if i % 4 ==0:
        break
    print(i)

#continue
for i in range(1,10):
    if i % 4 ==0:
        continue
    print(i)



    

    
