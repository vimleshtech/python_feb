a = int(input('etner data :'))
b = int(input('etner data :'))
c = int(input('etner data :'))

if a>b and a>c:
    print('a is gt')
elif b>a and b>c:
    print('b is gt')
else:
    print('c is gt')

#nested
if a>b:
    if a>c:
        print('a is gt')
    else:
        print('b is gt')
else:
    if b>c:
        print('b is gt')
    else:
        print('c is gt')




        
    

          
