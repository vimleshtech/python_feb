a = int(input("enter number "))
for a in range(1,a,3):
    if a%2 == 0:
        print("-" , a)
    else:
        print(a)
