''''a=int(input('enter number'))
sum=0
avg=0
c=0
for i in range(1,a,2):
    print(i)
    sum=sum+i
    c+=1
print('sum',sum)

avg=sum/c
print(avg)'''

'''a=int(input('enter number'))
for i in range(1,11):
    s=a*i
    print(a,'*',i,'=',s)'''


a=int(input('enter number'))
b=int(input('enter number'))
s=0
for i in range (a,b):
    if i%2 == 0 and i %3==0and  i%5 != 0 :
            s=s+i

print(s)
'''
else:
            print("it's div by 5")
    else:
        print("it' not div by 3")
            ")
        
'''






    
