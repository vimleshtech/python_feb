a = int(input("enter"))
out =1


for a in range(0,a,2):
    
    print(out)
    out = out+ 4+a
    
    
    
    
    
    
    
    
