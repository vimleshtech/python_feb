#declare empty list
data = []

while True:
    ch = input('press 1 for add 2 for show 3 for delete 4 for update 5 for max for minimum 7 for total 8 for average 9 for sorted and 0 for exit')
    
    if ch =='1':
            d = int(input('enter data :'))
            data.append(d) #add new value to existing list                          

    elif ch =='2':
        print(data)
        #for a in data:
        #    print(a)           
            

    elif ch =='3':
        d = int(input('enter data :'))
        if d in data:
            data.remove(d)
        else:
            print('given value is not found')

    elif ch =='4':
        d = int(input('enter data :'))
        for i in range(0,len(data)):
            if data[i] == d:
                nd = int(input('enter new data :'))
                data[i] = nd
                
    elif ch =='5':
        print(max(data))
            

    elif ch =='6':
         print(min(data))

             
    elif ch =='7':
        print(sum(data))
        
    elif ch =='8':
        s = sum(data)
        a=len(data)
        c=s/a
        print(c)

    elif ch =='9':
        data.sort()
        print(data)


    elif ch =='0':
            break

    else:
            print('invalid choice, plz try again !!!')


