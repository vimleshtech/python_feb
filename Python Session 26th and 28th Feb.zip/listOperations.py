data = [11,222,3,4,55]

print(len(data))
print(max(data))
print(min(data))
print(sum(data))

data.append(100)
print(data)

data.pop()
print(data)

data.insert(1,300)
print(data)

data.remove(300)
print(data)

data.sort()
print(data)
#print(data[::-1])

