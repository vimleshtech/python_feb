import os

src ='D:\RPA'
files = os.listdir(src)
#print(f)

w = open(r'D:\RPA\out\combined_data.txt','a')
         
for f in files:
    if f.endswith('.txt'):
        o = open(src+'\\'+f,'r')
        #print(o.read())
        for row in o.readlines():
            w.write(row)

w.close()
print('all content is copied')

        
        

