f = open('D:\RPA\Web - Scaping and Emailer.txt','r')

#print(f)
#print(f.read()) #read all content from file

#print(f.readline()) #read first line 
#print(f.readline()) #read 2nd line


#print(f.readlines())
#get row count
#get words count
wc = 0
#get particular word count
pwc = 0


lines = f.readlines()
for line in lines:
    print(line)
    words = line.split(' ')
    #print(words)
    wc += len(words)

    #get given word count
    for w in words:
        if w.replace('\n','').replace('\t','') == 'data':
            pwc +=1
    

f.close()

#row count
print('no of rows in file :',len(lines))
print('word count :',wc)
print('count of data :',pwc)







