f = open(r'D:\RPA\to_file.txt','a')


for i in range(1,5):
    data  = input('enter data :')
    
    f.write(data+'\n')

f.close()
