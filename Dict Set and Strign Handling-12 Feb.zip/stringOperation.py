#declare empty string variable
s =''
print(s)
print(type(s))

#string variable with data
s ="test"
print(type(s))
s =' test sjhsh4333 ^^ '
print(type(s))

print(s) #print data 

#function or operations
print(s.upper())
print(s.lower())
print(s.capitalize())
print(s.title())

print(len(s))


print(s.replace('e','xy'))

s = s.strip()
print(s)

print(list(s))

#split
o = s.split(' ') #break word by word
print(o)



#count
print(s.count('s'))

#slicer
print(s[2])
print(s[0:2])

print(s[1:5])


##condition
if s.islower():
     print('lower case')
else:
     print('upper case')

##condition
if s.isupper():
     print('upper case')
else:
     print('lower case')
     
     
if s.isdigit():
     print('digit')
else:
     print('no digit')
     

#
if s.endswith("a"): 
     print('end with a')
else:
     print('no end with a')

#
if s.startswith("a"): 
     print('start with a')
else:
     print('no start with a')
##
a =121
a =str(a)











     
     





     


















     






