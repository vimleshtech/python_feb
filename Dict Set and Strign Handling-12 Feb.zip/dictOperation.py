#empty dict
d ={}
print(d)


#dict with data 
data = {'a':'alpha','b':'beta',1:'one'}
print(type(data))
#print all
print(data)


#print/ search by key
print(data['a'])
print(data[1])


#dict with multi values
my_dict = {'name': 'John', 1: [2, 4, 3]}
print(my_dict)
print(my_dict[1])

      
#convert to dict from list/tuple 
my_dict = dict([(1,'apple'), (2,'ball')]) #{1: 'apple', 2: 'ball'}
print(my_dict)

#convert to dict
my_dict = dict({1:'apple', 2:'ball'})
print(my_dict)


#read data by key
print(my_dict[2])
print(my_dict.get(2))


#change data
my_dict[2] = 'alpha beta'
print(my_dict[2])
print(my_dict)

#add new item / key
my_dict['a'] = 'Downtown'
print(my_dict)

#
print(my_dict.pop(1)) #remove by given index
print(my_dict)

print(my_dict.popitem()) #remove from last 
print(my_dict)


#delete particular item
del my_dict[2]
print(my_dict)

#remove all
my_dict.clear()

#delete dict
del my_dict

#print(my_dict) #will throw error

















































