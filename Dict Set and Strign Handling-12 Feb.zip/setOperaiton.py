d = {'item1','item2','item1',11,22,11}
print(type(d))

#print all 
print(d)

#add element
d.add('test1')
print(d)


#add multiple , and udpate set
d.update([2,3,4])
print(d)


#remove
d.discard(4)
print(d)

#remove
d.remove(3)
print(d)

#union
A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}


print(A | B)#union

print(A & B) #intersection

print(A ^ B) #not common / difference 
















