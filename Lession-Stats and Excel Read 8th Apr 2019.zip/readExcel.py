import xlrd

#read excel workbook
wb = xlrd.open_workbook(r'C:\Users\vkumar15\Documents\Sandbox\Excel\Sample - Superstore.xls')

#read one sheet by given index
sheet = wb.sheet_by_index(2)

#get used rows and cols coun
rc = sheet.nrows
cc = sheet.ncols

print('row count :',rc)
print('col count :',cc)

#read first row/header
for i in range(0,cc):
     print(sheet.cell_value(0,i))


#read one column
for i in range(0,rc):
     print(sheet.cell_value(i,17))



#read all data
for i in range(0,rc):     
     for c in range(0,cc):
          print(sheet.cell_value(i,c))
          


          
          



