import random
print(random.random())


import re
a ='sljshgs 2223jh4jg3ghfghsfghsf4444'
print(re.findall('\d',a))
print(re.findall('\D',a))
print(re.findall('\w',a))
print(re.findall('\W',a))


#validate or match the pattern
s = input('enter the string :')

o = re.match('(.*) is (.*)',s)
print(o.groups())
print(o.group(1))
print(o.group(2))
if o:
     print('is matched')
else:
     print('not match')
     


#vaidate email
email = input('enter email id :')
o =  re.search('@gmail.com$',email)
if o:
     print('valid gmail account ')
else:
     print('invalid gmail account ')



## time
import time

t = time.localtime()
print(t)


for i in range(1,10):
     print(i)
     time.sleep(3)


     
     




     






     



