import socket

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name

port = 1213                # Reserve a port for yo	ur service.

s.connect((host, port))

print (s.recv(1024))

s.close                     # Close the socket when done
