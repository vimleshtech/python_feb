import tweepy #access to tweet app
from tweepy import OAuthHandler #authenication 
from textblob import TextBlob #text/tweet parse

c_key='TL7RyLnfilYH6xaoAlS0XFDCg'
c_key_token='u5uBn4P62PMIxT4uwUVTl1Ycx4rsfByFs6jl2e4SQ9zDjPIzCO'
a_token='919434545924935681-2woCDEXuXQdhJewDaCRBqHBYmi5SFDN'
a_token_secret='T29jqUm6rZqsRYO7AGc47GlgYTaAaN5OtJD0DATo1uBjh'

auth = OAuthHandler(c_key, c_key_token)
# set access token and secret
auth.set_access_token(a_token, a_token_secret)
# create tweepy API object to fetch tweets
api = tweepy.API(auth)



def get_tweet(user):
     print('user name :',user)
     out = api.search(q=user,count=3)
     for t in out:          
          print(t.text.encode())
          



users = ['Narendra Modi','Sonia Gandhi','Rahul Gandhi']
for u in users:
     get_tweet(u)






            




