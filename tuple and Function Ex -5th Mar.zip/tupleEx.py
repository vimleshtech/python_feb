
def sqr():
      a=int(input('enter number'))
      c=a*a
      print(c)
def cube():
       a=int(input('enter number'))
       c=a*a*a 
       print(c)
def rc1():
      a=int(input('enter number r value'))
      c=3.14*a*a
      print(c)

def rc2(l,b):
    
      c=l*b
      print(c)
      
def sip(p,t,r):
      
      d=100
      si=(p*t*r)/d
      print('simple interst',si)
      

#rc2(22,23)

sip(23,23,23)

#cube()

#rc()

