#-no argument no return
def welcome():
     print('welcome to function world')
     print('there are multiple function in this file/module')
     
#-no argument with return
def getData():
     eid = input('enter data :')
     return eid

#-argument with no return
def add(a,b):
     c =a+b
     print('sum of two numbers :',c)
     
#-argument with return 
def mul(a,b):
     c =a*b
     return c

#-function with multiple return
def getnums():
     a = int(input('enter data :'))
     b = int(input('enter data :'))
     return a,b




#call to function
'''
welcome()
welcome()

a = getData()
print(a)
add(11,22)
add(11,220)

o = mul(11,23)
print(o)
add(o,100)
'''

x,y = getnums()
add(x,y)
x,y = getnums()
add(x,y)









