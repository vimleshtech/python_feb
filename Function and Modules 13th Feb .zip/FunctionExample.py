x =10
#-No argument no return
def wel():
     print('welcome to function world')
     print('this module contains 1. wel 2. getdata 3. add and 4. mul function ')
     x =1 #local variable 
		
#-No argument with return
def getdata():
     #print(x) #cannot be access since x is local variable of wel function
     print(x) #not x can be access because this is global 
     a =int(input('enter data  :'))
     b =int(input('enter data  :'))
     return a,b  #python can return multiple values from function 
#-Argument with no return
def add(a,b):
     c  = a+b
     print('sum of two numbers :',c)
     
#-Argument with return
def mul(a,b):
       c = a*b
       return c
     
#call or invoke to function
wel()
x,y = getdata()
print(x-y)

#cal with argument
add(11,2)
add(x,y)

o = mul(11,3)
print(o)













