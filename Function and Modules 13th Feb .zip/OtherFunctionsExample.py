#-Function with default argument

def add(a,b,c =0,d=0):
     x =a+b+c+d
     print('sum of numbers :',x)
     
#Python doesn't support function overloading, function will be overwrite automatically if name of the function will same     
def add1(a): #there is no use this function 
     print(a)

def add1(a,b):
     print(a+b)
     
#-Function with dynamic argument
def mul(*arg):
     print(arg) #default type of argument is tuple
     x =1
     for d in arg:
          x *=d
     print('multiplication of all numbers :',x)     
     
#-Recussive function #function which will call/invoke to itself
def fact(n):
     if n ==1:
          return n
     else:
          return n*fact(n-1) # 5* 4 * 3 *2 *1 
     
#-Anonyms or Lambda function
def make_incrementor(n):
     return lambda x: x + n


add(11,22)
add(11,22,3)
add(11,22,44,33)

add1(1,2)

mul(11,2)
mul(11,2,2)
mul(11,2,3,4)
mul(11,2,3,4,5)
mul(11,2,3,4,5,4)


#call to fact function(recurrive)
o = fact(5)
print(o)

#call to lambda
f = make_incrementor(42)
print(f(0))
print(f(1))
print(f(2))








