#-No argument no return
def wel():
     print('welcome to function world')
     print('this module contains 1. wel 2. getdata 3. add and 4. mul function ')
     
		
#-No argument with return
def getdata():    
     a =int(input('enter data  :'))
     b =int(input('enter data  :'))
     return a,b  #python can return multiple values from function 
#-Argument with no return
def add(a,b):
     c  = a+b
     print('sum of two numbers :',c)
     
#-Argument with return
def mul(a,b):
       c = a*b
       return c
