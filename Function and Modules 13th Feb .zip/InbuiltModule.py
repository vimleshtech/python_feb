#inbuld module
import math

print(math.pi)
print(math.sqrt(10))
print(math.factorial(7))

print(math.pow(2,6))


##random module
import random
print(random.randint(1,10))
print(random.random()*1000)
