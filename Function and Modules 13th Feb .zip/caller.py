#example  1
import Module

Module.add(11,2)
o = Module.mul(11,22)
print(o)


#example 2
from Module import add,wel
wel()
add(11,3)

#example 3
from Module import * #import all functions, classes
add(1,2)
wel()
mul(11,22)

#example 4
import Module as m #here m is alias
m.add(11,2)










