s ='RAJAT'
o = list(s)
ss=''
for c in o:
     ss +=c
     print(ss)
     
     
