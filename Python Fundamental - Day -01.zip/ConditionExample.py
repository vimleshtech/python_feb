n = int(input('enter data :'))

#check even or odd

if n%2 ==0:
     print('even')
else:
     print('odd')

     

#check greater no in three inputs
a = int(input('enter bdata :'))
b = int(input('enter data :'))
c = int(input('enter data :'))

if a>b and a>c:
     print('a is greater')
elif b>a and b>c:
     print('b is greater')
else:
     print('c is greater')

#formuLA
a = int(input('enter cube :'))
b = int(input('enter cube :'))
c = int(input('enter cube :'))
d = int(input('enter cube :'))

res = a+b+c

if res==d:
     print('satisfied')
else:
     print('not satisfies')



     






     
