squr= int(input ('enter number'))
a =  squr*squr
print(a)
