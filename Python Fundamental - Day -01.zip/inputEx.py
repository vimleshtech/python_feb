name = input('enter data :') #default is string
hs = int(input('enter mark in hindi :'))

print(name)
print(hs)

