a =1
b =3
c =a+b
print(c)


a =1
print(type(a))

a =333.3
print(type(a))

a= 'sjhsh'
print(type(a))


a="skhsjhgh2"
print(type(a))


a =True
print(type(a))

a =[11,222,33,4]
print(type(a))


a= (11,22,3)
print(type(a))


a ={'a':'alpah','b':'beta'}
print(type(a))

a ={'dove','lux','dove'}
print(type(a))
print(a)




salary= int(input ('salary'))
hra =0
da =0

if salary>5000<10000:
     
     hra= salary*.10
     da= salary*0.5

elif salary>5000<10000:
     
     hra= salary*.10
     da= salary*0.5

print(hra,'hra')
print(da,'da')
     



cs=int(input('enrter marks'))
s=int(input('enrter marks'))
ps=int(input('enrter marks'))
fs=int(input('enrter marks'))
hs=int(input('enrter marks'))
total=cs+s+ps+fs+hs

if total>60:
     print('first')
elif total>50<59:
     print('second')
elif total>40<49:
     print('third')     
else:
     print('fail')






